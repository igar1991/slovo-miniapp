self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5579f52e14ff393b0960ee422aef490d",
    "url": "./index.html"
  },
  {
    "revision": "19a7b521201ae0a90482",
    "url": "./static/css/2.814df5ce.chunk.css"
  },
  {
    "revision": "4fb0f315f778044c255e",
    "url": "./static/css/main.01d8f07c.chunk.css"
  },
  {
    "revision": "19a7b521201ae0a90482",
    "url": "./static/js/2.ab63e854.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.ab63e854.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4fb0f315f778044c255e",
    "url": "./static/js/main.c66885d0.chunk.js"
  },
  {
    "revision": "f4b8c6c52c33b6eca44f",
    "url": "./static/js/runtime-main.710498db.js"
  }
]);